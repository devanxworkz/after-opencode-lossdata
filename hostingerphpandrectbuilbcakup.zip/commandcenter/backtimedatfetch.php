<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// ==== Database Config ====
$host     = "103.174.148.224";
$port     = "5432";
$dbname   = "rivotcommandcenterdb";
$user     = "rivotcommandcenter";
$password = "123";

// ==== Connect to PostgreSQL ====
$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";
$conn = pg_connect($conn_string);

if (!$conn) {
    http_response_code(500);
    echo json_encode([
        "status"  => "error",
        "message" => "Database connection failed"
    ]);
    exit;
}

// ==== Get Parameters ====
$vin   = $_GET['vin']   ?? '';
$start = $_GET['start'] ?? '';
$end   = $_GET['end']   ?? '';

if (!$vin || !$start || !$end) {
    http_response_code(400);
    echo json_encode([
        "status"  => "error",
        "message" => "Missing required parameters: vin, start, end"
    ]);
    pg_close($conn);
    exit;
}

// ==== Normalize ISO8601 input (replace 'T' with space) ====
$start = str_replace('T', ' ', $start);
$end   = str_replace('T', ' ', $end);

// ==== Add seconds if not included ====
if (strlen($start) === 16) $start .= ':00';  
if (strlen($end) === 16)   $end   .= ':00';

// ==== Validate timestamps ====
$start_ts = strtotime($start);
$end_ts   = strtotime($end);

if ($start_ts === false || $end_ts === false) {
    http_response_code(400);
    echo json_encode([
        "status"  => "error",
        "message" => "Invalid date format. Expected: YYYY-MM-DDTHH:MM"
    ]);
    pg_close($conn);
    exit;
}

// Format timestamps for PostgreSQL
$start = date("Y-m-d H:i:s", $start_ts);
$end   = date("Y-m-d H:i:s", $end_ts);

// ==== SQL Query ====
$sql = "SELECT 
            vinnumber,
            time, 
            speed_kmph, 
            motortemp, 
            controllermostemp, 
            bmsmostemp, 
            currentconsumption, 
            ntc,
            soc,
            batvoltage,
            tripkm,
            inah,
            outah,
            lat_long
        FROM realtimedata
        WHERE vinnumber = $1
          AND time BETWEEN $2 AND $3
        ORDER BY time DESC";

// ==== Execute Query ====
$result = pg_query_params($conn, $sql, [$vin, $start, $end]);

if (!$result) {
    http_response_code(500);
    echo json_encode([
        "status"  => "error",
        "message" => "Query execution failed"
    ]);
    pg_close($conn);
    exit;
}

// ==== Fetch Data ====
$data = [];
while ($row = pg_fetch_assoc($result)) {
    // Keep ntc as an array of strings/numbers exactly as stored
    $ntcArray = [];
    if (!empty($row["ntc"])) {
        // Split by commas, keep all values as-is
        $ntcArray = array_map('trim', explode(',', $row["ntc"]));
        // Convert numeric strings to floats, keep other strings intact
        $ntcArray = array_map(function($v) {
            return is_numeric($v) ? (float)$v : $v;
        }, $ntcArray);
    }

    $data[] = [
        "time" => $row["time"],
        "currentconsumption" => isset($row["currentconsumption"]) ? (float)$row["currentconsumption"] : null,
        "speed_kmph" => isset($row["speed_kmph"]) ? (float)$row["speed_kmph"] : null,
        "motortemp" => isset($row["motortemp"]) ? (float)$row["motortemp"] : null,
        "controllermostemp" => isset($row["controllermostemp"]) ? (float)$row["controllermostemp"] : null,
        "bmsmostemp" => isset($row["bmsmostemp"]) ? (float)$row["bmsmostemp"] : null,
        "ntc" => $ntcArray,
        "soc" => isset($row["soc"]) ? (float)$row["soc"] : null,
        "batvoltage" => isset($row["batvoltage"]) ? (float)$row["batvoltage"] : null,
        "tripkm" => isset($row["tripkm"]) ? (float)$row["tripkm"] : null,
        "inah" => isset($row["inah"]) ? (float)$row["inah"] : null,
        "outah" => isset($row["outah"]) ? (float)$row["outah"] : null,
        "lat_long" => !empty($row["lat_long"]) 
            ? array_map('floatval', array_map('trim', explode(',', $row["lat_long"])))
            : null
    ];
}

// ==== Return Response ====
echo json_encode([
    "status" => "success",
    "count"  => count($data),
    "data"   => $data
]);

pg_close($conn);
?>
