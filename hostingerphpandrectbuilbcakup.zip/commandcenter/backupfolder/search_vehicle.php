<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

// $host = "localhost";
// $dbname = "NX100";
// $user = "postgres";
// $pass = "1234";


$host = "103.174.148.224";
$port = "5432";
$dbname = "rivotcommandcenterdb";
$user = "rivotcommandcenter";
$pass = "123";
$conn = pg_connect("host=$host dbname=$dbname user=$user password=$pass");

$q = $_GET['q'] ?? '';
if (!$q) { echo json_encode([]); exit; }

$sql = "
  SELECT vinnumber, ownername, phonenumber 
  FROM allvin
  WHERE vinnumber ILIKE '%$q%'
     OR ownername ILIKE '%$q%'
     OR phonenumber ILIKE '%$q%'
  LIMIT 10;
";

$result = pg_query($conn, $sql);
$data = pg_fetch_all($result);
echo json_encode($data ?: []);
?>
