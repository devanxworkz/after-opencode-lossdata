<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// DB credentials
$host = "103.174.148.224";
$port = "5432";
$dbname = "rivotcommandcenterdb";
$user = "rivotcommandcenter";
$password = "123"; // fixed variable

// Connect to DB
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");
if (!$conn) {
    echo json_encode(["status"=>"error", "message"=>"Database connection failed", "pg_error"=>pg_last_error()]);
    exit;
}

// Parameters
$vin     = isset($_GET['vin']) ? trim($_GET['vin']) : null;
$latest  = isset($_GET['latest']) && $_GET['latest'] == 1;
$start   = isset($_GET['start']) ? trim($_GET['start']) : null;
$end     = isset($_GET['end']) ? trim($_GET['end']) : null;

// Format start/end to proper timestamp
if ($start) $start = date("Y-m-d H:i:s", strtotime($start));
if ($end) $end = date("Y-m-d H:i:s", strtotime($end));

// Build query
if ($latest) {
    if ($vin) {
        $query = "SELECT * FROM realtimedata WHERE vinnumber = $1 ORDER BY time DESC LIMIT 1";
        $params = [$vin];
    } else {
        $query = "SELECT * FROM realtimedata ORDER BY time DESC LIMIT 1";
        $params = [];
    }
} else {
    $conditions = [];
    $params = [];
    $i = 1;

    if ($vin) {
        $conditions[] = "vinnumber = $" . $i++;
        $params[] = $vin;
    }
    if ($start && $end) {
        $conditions[] = "time BETWEEN $" . $i++ . " AND $" . $i++;
        $params[] = $start;
        $params[] = $end;
    }

    $whereClause = count($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";

    if ($start && $end) {
        $query = "SELECT * FROM realtimedata $whereClause ORDER BY time ASC";
    } else {
        $query = "
            SELECT * FROM (
                SELECT * FROM realtimedata
                $whereClause
                ORDER BY time DESC
                LIMIT 50
            ) sub
            ORDER BY time ASC
        ";
    }
}

// Run query
if (!empty($params)) {
    $result = pg_query_params($conn, $query, $params);
} else {
    $result = pg_query($conn, $query);
}

// Fetch results
$data = [];
if ($result) {
    while ($row = pg_fetch_assoc($result)) {
        $data[] = $row;
    }
    echo json_encode(["status"=>"success","count"=>count($data),"data"=>$data]);
} else {
    echo json_encode(["status"=>"error","message"=>"Query failed","pg_error"=>pg_last_error()]);
}

pg_close($conn);
?>
