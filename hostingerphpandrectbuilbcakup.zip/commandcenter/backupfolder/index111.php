
// header("Access-Control-Allow-Origin: *");
// header("Content-Type: application/json");

// PostgreSQL connection details
// $host = "localhost";
// $port = "5432";
// $dbname = "NX100";
// $user = "postgres";
// $password = "1234";


// Connect to PostgreSQL
// $connStr = "host=$host port=$port dbname=$dbname user=$user password=$password";
// $conn = pg_connect($connStr);

// if (!$conn) {
//     echo json_encode(["error" => "Connection failed"]);
//     exit;
// }

// Fetch all VINNumbers
// $query = "SELECT VINNumber FROM AllVIN";
// $result = pg_query($conn, $query);

// $vins = [];

// while ($row = pg_fetch_assoc($result)) {
//     $vins[] = $row['vinnumber'];
// }

// echo json_encode($vins);
// ?>



<?php
<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
// your DB connection code here
?>

$conn = pg_connect("host=localhost 
port=5432 
dbname=NX100 user=postgres password=123");

if (!$conn) {
    echo json_encode([]);
    exit;
}

// $result = pg_query($conn, "SELECT vinnumber FROM allvin");
// $vins = [];

$query = "SELECT VINNumber FROM AllVIN";
$result = pg_query($conn, $query);
$vins = [];

while ($row = pg_fetch_assoc($result)) {
    $vins[] = $row['VINNumber'];
}

echo json_encode($vins);
?>
