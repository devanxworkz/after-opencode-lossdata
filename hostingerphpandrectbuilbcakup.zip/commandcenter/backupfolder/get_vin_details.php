<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// PostgreSQL credentials
$host = "103.174.148.224";
$port = "5432";
$dbname = "rivotcommandcenterdb";
$user = "rivotcommandcenter";
$password = "123"; // fixed variable

// Connect to PostgreSQL
$connStr = "host=$host port=$port dbname=$dbname user=$user password=$password";
$conn = pg_connect($connStr);

if (!$conn) {
    echo json_encode(["status"=>"error","message"=>"Connection failed","pg_error"=>pg_last_error()]);
    exit;
}

// Get VIN from request
$vin = $_GET['vin'] ?? '';

if (empty($vin)) {
    echo json_encode(["status"=>"error","message"=>"VIN not provided"]);
    exit;
}

// Query table (use lowercase if table/column names are lowercase)
$query = "SELECT * FROM allvin WHERE vinnumber = $1 LIMIT 1";
$result = pg_query_params($conn, $query, [$vin]);

if (!$result) {
    echo json_encode(["status"=>"error","message"=>"Query failed","pg_error"=>pg_last_error()]);
    pg_close($conn);
    exit;
}

// Fetch result
$row = pg_fetch_assoc($result);

if ($row) {
    echo json_encode(["status"=>"success","data"=>$row]);
} else {
    echo json_encode(["status"=>"error","message"=>"VIN not found"]);
}

pg_close($conn);
?>
