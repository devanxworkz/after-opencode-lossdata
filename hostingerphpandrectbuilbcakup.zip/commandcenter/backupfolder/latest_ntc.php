<?php
// latest_ntc.php

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

// // ✅ DB config
// $host = "localhost";
// $dbname = "NX100";
// $user = "postgres";
// $pass = "1234";
// $port = "5432"; // adjust if different

$host = "103.174.148.224";
$port = "5432";
$dbname = "rivotcommandcenterdb";
$user = "rivotcommandcenter";
$pass = "123";



// ✅ Connect
$conn = pg_connect("host=$host dbname=$dbname user=$user password=$pass port=$port");
if (!$conn) {
    echo json_encode(["error" => "DB connection failed"]);
    exit;
}

// ✅ VIN param
$vin = isset($_GET['vin']) ? $_GET['vin'] : "";
if ($vin === "") {
    echo json_encode(["error" => "VIN parameter required"]);
    exit;
}

// ✅ Query only latest row
$sql = "
    SELECT time, ntc
    FROM  realtimedata
    WHERE vinnumber = $1
    ORDER BY time DESC
    LIMIT 1
";

$result = pg_query_params($conn, $sql, [$vin]);
if (!$result) {
    echo json_encode(["error" => "Query failed"]);
    exit;
}

$row = pg_fetch_assoc($result);
if ($row) {
    // Convert string into array
    $row['ntc_array'] = explode(",", $row['ntc']);
    echo json_encode($row);
} else {
    echo json_encode([]);
}
?>
