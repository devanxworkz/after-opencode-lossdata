<?php
// Database connection settings
// $host = "localhost"; // or server IP/domain
// $port = "5432";
// $dbname = "your_database_name";
// $user = "your_db_user";
// $password = "your_db_password";

$host = '103.174.148.224';
$port = '5432';
$dbname = 'rivotcommandcenterdb';
$user = 'rivotcommandcenter';
$password = '123';


// Create connection
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Check connection
if (!$conn) {
    echo "Error: Unable to connect to PostgreSQL server.\n";
    exit;
} else {
    echo "Connected to PostgreSQL successfully!\n";
}
?>
