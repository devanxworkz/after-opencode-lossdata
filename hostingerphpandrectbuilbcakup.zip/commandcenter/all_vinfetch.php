<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// PostgreSQL credentials
$host = "103.174.148.224";
$port = "5432";
$dbname = "rivotcommandcenterdb";
$user = "rivotcommandcenter";
$password = "123";

try {
    // Connect using PDO
    $conn = new PDO("pgsql:host=$host;port=$port;dbname=$dbname", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch all VINs
    $stmt = $conn->query("SELECT vinnumber FROM allvin ORDER BY vinnumber ASC");
    $vins = $stmt->fetchAll(PDO::FETCH_COLUMN); // fetch only the first column

    // Return JSON response
    echo json_encode([
        "status" => "success",
        "count"  => count($vins),
        "vins"   => $vins
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "status"   => "error",
        "message"  => "Database connection failed",
        "pg_error" => $e->getMessage()
    ]);
}
?>
