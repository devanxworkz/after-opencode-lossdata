<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

// ==== Database Config ====
$host     = "103.174.148.224";
$port     = "5432";
$dbname   = "rivotcommandcenterdb";
$user     = "rivotcommandcenter";
$password = "123";

// ==== Connect ====
$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";
$conn = pg_connect($conn_string);

if (!$conn) {
    echo json_encode(["status" => "error", "message" => "DB connection failed"]);
    exit;
}

// ==== Parameters ====
$vin   = $_GET['vin'] ?? '';
$start = $_GET['start'] ?? '';
$end   = $_GET['end'] ?? '';

if (!$vin || !$start || !$end) {
    echo json_encode(["status" => "error", "message" => "Missing parameters"]);
    exit;
}

$start = str_replace('T', ' ', $start);
$end   = str_replace('T', ' ', $end);
if (strlen($start) === 16) $start .= ':00';
if (strlen($end) === 16)   $end   .= ':00';

$sql = "
SELECT 
  time,
  vinnumber,
  lat_long,
  speed_kmph,
  currentconsumption,
  soc,
  tripkm,
  batvoltage,
  motortemp,
  controllermostemp,
  bmsmostemp
FROM realtimedata
WHERE vinnumber = $1
  AND time BETWEEN $2 AND $3
  AND lat_long IS NOT NULL
ORDER BY time ASC;
";

$result = pg_query_params($conn, $sql, [$vin, $start, $end]);

if (!$result) {
    echo json_encode(["status" => "error", "message" => "Query failed"]);
    exit;
}

$data = [];
while ($row = pg_fetch_assoc($result)) {
    if (!empty($row["lat_long"])) {
        $latlng = array_map('floatval', explode(',', $row["lat_long"]));
        if (count($latlng) === 2) {
            $data[] = [
                "time" => $row["time"],
                "lat" => $latlng[0],
                "lng" => $latlng[1],
                "speed_kmph" => isset($row["speed_kmph"]) ? (float)$row["speed_kmph"] : null,
                "currentconsumption" => isset($row["currentconsumption"]) ? (float)$row["currentconsumption"] : null,
                "soc" => isset($row["soc"]) ? (float)$row["soc"] : null,
                "tripkm" => isset($row["tripkm"]) ? (float)$row["tripkm"] : null,
                "motortemp" => isset($row["motortemp"]) ? (float)$row["motortemp"] : null,
                "controllermostemp" => isset($row["controllermostemp"]) ? (float)$row["controllermostemp"] : null,
                "bmsmostemp" => isset($row["bmsmostemp"]) ? (float)$row["bmsmostemp"] : null,
                "batvoltage" => isset($row["batvoltage"]) ? (float)$row["batvoltage"] : null

            ];
        }
    }
}

echo json_encode(["status" => "success", "count" => count($data), "data" => $data]);
pg_close($conn);
?>
